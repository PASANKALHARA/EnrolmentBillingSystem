﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEditStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.chkReportCard = New System.Windows.Forms.CheckBox
        Me.chkCertification = New System.Windows.Forms.CheckBox
        Me.chkBirthCert = New System.Windows.Forms.CheckBox
        Me.chkPic = New System.Windows.Forms.CheckBox
        Me.txtguardianadd = New System.Windows.Forms.RichTextBox
        Me.Label61 = New System.Windows.Forms.Label
        Me.txtguardiantel = New System.Windows.Forms.TextBox
        Me.Label60 = New System.Windows.Forms.Label
        Me.txtguardian = New System.Windows.Forms.TextBox
        Me.Label59 = New System.Windows.Forms.Label
        Me.cboAddSy = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtLastSchoolAttend = New System.Windows.Forms.RichTextBox
        Me.txtPBirth = New System.Windows.Forms.RichTextBox
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip
        Me.tsSave = New System.Windows.Forms.ToolStripButton
        Me.tsNew = New System.Windows.Forms.ToolStripButton
        Me.tsAdd = New System.Windows.Forms.ToolStripButton
        Me.txtAddress = New System.Windows.Forms.RichTextBox
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label51 = New System.Windows.Forms.Label
        Me.rdoFemale = New System.Windows.Forms.RadioButton
        Me.rdoMale = New System.Windows.Forms.RadioButton
        Me.dtpDbirth = New System.Windows.Forms.DateTimePicker
        Me.txtHeight = New System.Windows.Forms.TextBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtWeigth = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtStudentId = New System.Windows.Forms.TextBox
        Me.txtAge = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtMName = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtFName = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtLName = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkReportCard)
        Me.GroupBox2.Controls.Add(Me.chkCertification)
        Me.GroupBox2.Controls.Add(Me.chkBirthCert)
        Me.GroupBox2.Controls.Add(Me.chkPic)
        Me.GroupBox2.Location = New System.Drawing.Point(749, 66)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 265)
        Me.GroupBox2.TabIndex = 33
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Requirements"
        '
        'chkReportCard
        '
        Me.chkReportCard.AutoSize = True
        Me.chkReportCard.Location = New System.Drawing.Point(26, 41)
        Me.chkReportCard.Name = "chkReportCard"
        Me.chkReportCard.Size = New System.Drawing.Size(83, 17)
        Me.chkReportCard.TabIndex = 18
        Me.chkReportCard.Text = "Report Card"
        Me.chkReportCard.UseVisualStyleBackColor = True
        '
        'chkCertification
        '
        Me.chkCertification.AutoSize = True
        Me.chkCertification.Location = New System.Drawing.Point(28, 203)
        Me.chkCertification.Name = "chkCertification"
        Me.chkCertification.Size = New System.Drawing.Size(81, 17)
        Me.chkCertification.TabIndex = 21
        Me.chkCertification.Text = "Certification"
        Me.chkCertification.UseVisualStyleBackColor = True
        '
        'chkBirthCert
        '
        Me.chkBirthCert.AutoSize = True
        Me.chkBirthCert.Location = New System.Drawing.Point(26, 99)
        Me.chkBirthCert.Name = "chkBirthCert"
        Me.chkBirthCert.Size = New System.Drawing.Size(97, 17)
        Me.chkBirthCert.TabIndex = 19
        Me.chkBirthCert.Text = "Birth Certificate"
        Me.chkBirthCert.UseVisualStyleBackColor = True
        '
        'chkPic
        '
        Me.chkPic.AutoSize = True
        Me.chkPic.Location = New System.Drawing.Point(26, 156)
        Me.chkPic.Name = "chkPic"
        Me.chkPic.Size = New System.Drawing.Size(93, 17)
        Me.chkPic.TabIndex = 20
        Me.chkPic.Text = "1x1 ID Picture"
        Me.chkPic.UseVisualStyleBackColor = True
        '
        'txtguardianadd
        '
        Me.txtguardianadd.Location = New System.Drawing.Point(382, 227)
        Me.txtguardianadd.Name = "txtguardianadd"
        Me.txtguardianadd.Size = New System.Drawing.Size(361, 60)
        Me.txtguardianadd.TabIndex = 13
        Me.txtguardianadd.Text = ""
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(379, 211)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(51, 13)
        Me.Label61.TabIndex = 34
        Me.Label61.Text = "Address :"
        '
        'txtguardiantel
        '
        Me.txtguardiantel.Location = New System.Drawing.Point(9, 267)
        Me.txtguardiantel.Name = "txtguardiantel"
        Me.txtguardiantel.Size = New System.Drawing.Size(367, 20)
        Me.txtguardiantel.TabIndex = 12
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(6, 254)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(28, 13)
        Me.Label60.TabIndex = 32
        Me.Label60.Text = "Tel :"
        '
        'txtguardian
        '
        Me.txtguardian.Location = New System.Drawing.Point(9, 231)
        Me.txtguardian.Name = "txtguardian"
        Me.txtguardian.Size = New System.Drawing.Size(367, 20)
        Me.txtguardian.TabIndex = 11
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(6, 218)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(56, 13)
        Me.Label59.TabIndex = 30
        Me.Label59.Text = "Guardian :"
        '
        'cboAddSy
        '
        Me.cboAddSy.FormattingEnabled = True
        Me.cboAddSy.Location = New System.Drawing.Point(484, 310)
        Me.cboAddSy.Name = "cboAddSy"
        Me.cboAddSy.Size = New System.Drawing.Size(259, 21)
        Me.cboAddSy.TabIndex = 15
        '
        'Label11
        '
        Me.Label11.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 30.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(0, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(1041, 58)
        Me.Label11.TabIndex = 38
        Me.Label11.Text = "Edit Student"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtLastSchoolAttend
        '
        Me.txtLastSchoolAttend.Location = New System.Drawing.Point(9, 310)
        Me.txtLastSchoolAttend.Name = "txtLastSchoolAttend"
        Me.txtLastSchoolAttend.Size = New System.Drawing.Size(469, 37)
        Me.txtLastSchoolAttend.TabIndex = 14
        Me.txtLastSchoolAttend.Text = ""
        '
        'txtPBirth
        '
        Me.txtPBirth.Location = New System.Drawing.Point(382, 133)
        Me.txtPBirth.Name = "txtPBirth"
        Me.txtPBirth.Size = New System.Drawing.Size(361, 37)
        Me.txtPBirth.TabIndex = 5
        Me.txtPBirth.Text = ""
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(50, 50)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsSave, Me.tsNew, Me.tsAdd})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 448)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1041, 57)
        Me.ToolStrip1.TabIndex = 40
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'tsSave
        '
        Me.tsSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsSave.Image = Global.EnrolmentBillingSystem.My.Resources.Resources.save
        Me.tsSave.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsSave.Name = "tsSave"
        Me.tsSave.Size = New System.Drawing.Size(54, 54)
        Me.tsSave.Text = "Save"
        '
        'tsNew
        '
        Me.tsNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsNew.Image = Global.EnrolmentBillingSystem.My.Resources.Resources.list
        Me.tsNew.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsNew.Name = "tsNew"
        Me.tsNew.Size = New System.Drawing.Size(54, 54)
        Me.tsNew.Text = "List"
        '
        'tsAdd
        '
        Me.tsAdd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.tsAdd.Image = Global.EnrolmentBillingSystem.My.Resources.Resources.add
        Me.tsAdd.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.tsAdd.Name = "tsAdd"
        Me.tsAdd.Size = New System.Drawing.Size(54, 54)
        Me.tsAdd.Text = "Add New Student"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(9, 133)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(367, 37)
        Me.txtAddress.TabIndex = 4
        Me.txtAddress.Text = ""
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(481, 290)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(71, 13)
        Me.Label29.TabIndex = 23
        Me.Label29.Text = "School Year :"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(6, 290)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(115, 13)
        Me.Label51.TabIndex = 23
        Me.Label51.Text = "Last School Attended :"
        '
        'rdoFemale
        '
        Me.rdoFemale.AutoSize = True
        Me.rdoFemale.Location = New System.Drawing.Point(393, 191)
        Me.rdoFemale.Name = "rdoFemale"
        Me.rdoFemale.Size = New System.Drawing.Size(59, 17)
        Me.rdoFemale.TabIndex = 8
        Me.rdoFemale.TabStop = True
        Me.rdoFemale.Text = "Female"
        Me.rdoFemale.UseVisualStyleBackColor = True
        '
        'rdoMale
        '
        Me.rdoMale.AutoSize = True
        Me.rdoMale.Location = New System.Drawing.Point(339, 191)
        Me.rdoMale.Name = "rdoMale"
        Me.rdoMale.Size = New System.Drawing.Size(48, 17)
        Me.rdoMale.TabIndex = 7
        Me.rdoMale.TabStop = True
        Me.rdoMale.Text = "Male"
        Me.rdoMale.UseVisualStyleBackColor = True
        '
        'dtpDbirth
        '
        Me.dtpDbirth.CustomFormat = "yyyy-MM-dd"
        Me.dtpDbirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDbirth.Location = New System.Drawing.Point(9, 190)
        Me.dtpDbirth.Name = "dtpDbirth"
        Me.dtpDbirth.Size = New System.Drawing.Size(158, 20)
        Me.dtpDbirth.TabIndex = 6
        '
        'txtHeight
        '
        Me.txtHeight.Location = New System.Drawing.Point(597, 190)
        Me.txtHeight.Name = "txtHeight"
        Me.txtHeight.Size = New System.Drawing.Size(146, 20)
        Me.txtHeight.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(594, 173)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Height :"
        '
        'txtWeigth
        '
        Me.txtWeigth.Location = New System.Drawing.Point(459, 191)
        Me.txtWeigth.Name = "txtWeigth"
        Me.txtWeigth.Size = New System.Drawing.Size(132, 20)
        Me.txtWeigth.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(457, 175)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(47, 13)
        Me.Label9.TabIndex = 16
        Me.Label9.Text = "Weight :"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(336, 174)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Sex :"
        '
        'txtStudentId
        '
        Me.txtStudentId.Enabled = False
        Me.txtStudentId.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtStudentId.Location = New System.Drawing.Point(9, 46)
        Me.txtStudentId.Name = "txtStudentId"
        Me.txtStudentId.Size = New System.Drawing.Size(328, 23)
        Me.txtStudentId.TabIndex = 35
        '
        'txtAge
        '
        Me.txtAge.Enabled = False
        Me.txtAge.Location = New System.Drawing.Point(173, 189)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(143, 20)
        Me.txtAge.TabIndex = 8
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(6, 26)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(82, 17)
        Me.Label27.TabIndex = 37
        Me.Label27.Text = "Student ID :"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.txtguardianadd)
        Me.GroupBox1.Controls.Add(Me.txtStudentId)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.Label61)
        Me.GroupBox1.Controls.Add(Me.txtguardiantel)
        Me.GroupBox1.Controls.Add(Me.Label60)
        Me.GroupBox1.Controls.Add(Me.txtguardian)
        Me.GroupBox1.Controls.Add(Me.Label59)
        Me.GroupBox1.Controls.Add(Me.cboAddSy)
        Me.GroupBox1.Controls.Add(Me.txtLastSchoolAttend)
        Me.GroupBox1.Controls.Add(Me.txtPBirth)
        Me.GroupBox1.Controls.Add(Me.txtAddress)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.Label51)
        Me.GroupBox1.Controls.Add(Me.rdoFemale)
        Me.GroupBox1.Controls.Add(Me.rdoMale)
        Me.GroupBox1.Controls.Add(Me.dtpDbirth)
        Me.GroupBox1.Controls.Add(Me.txtHeight)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.txtWeigth)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txtAge)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtMName)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtFName)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtLName)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(34, 66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(963, 363)
        Me.GroupBox1.TabIndex = 36
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Basic Information"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(170, 173)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Age :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 174)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 13)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Date Of Birth :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(379, 117)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(78, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Place Of Birth :"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 117)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(51, 13)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Address :"
        '
        'txtMName
        '
        Me.txtMName.Location = New System.Drawing.Point(519, 85)
        Me.txtMName.Name = "txtMName"
        Me.txtMName.Size = New System.Drawing.Size(224, 20)
        Me.txtMName.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(516, 69)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Middle Name :"
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(287, 85)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(226, 20)
        Me.txtFName.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(284, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Given Name :"
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(9, 85)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(272, 20)
        Me.txtLName.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(73, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Family Name :"
        '
        'frmEditStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(1041, 505)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmEditStudent"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Edit Student"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkReportCard As System.Windows.Forms.CheckBox
    Friend WithEvents chkCertification As System.Windows.Forms.CheckBox
    Friend WithEvents chkBirthCert As System.Windows.Forms.CheckBox
    Friend WithEvents chkPic As System.Windows.Forms.CheckBox
    Friend WithEvents txtguardianadd As System.Windows.Forms.RichTextBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents txtguardiantel As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents txtguardian As System.Windows.Forms.TextBox
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents cboAddSy As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtLastSchoolAttend As System.Windows.Forms.RichTextBox
    Friend WithEvents txtPBirth As System.Windows.Forms.RichTextBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents tsSave As System.Windows.Forms.ToolStripButton
    Friend WithEvents tsNew As System.Windows.Forms.ToolStripButton
    Friend WithEvents txtAddress As System.Windows.Forms.RichTextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents rdoFemale As System.Windows.Forms.RadioButton
    Friend WithEvents rdoMale As System.Windows.Forms.RadioButton
    Friend WithEvents dtpDbirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtHeight As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtWeigth As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtStudentId As System.Windows.Forms.TextBox
    Friend WithEvents txtAge As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtMName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtFName As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtLName As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents tsAdd As System.Windows.Forms.ToolStripButton
End Class
