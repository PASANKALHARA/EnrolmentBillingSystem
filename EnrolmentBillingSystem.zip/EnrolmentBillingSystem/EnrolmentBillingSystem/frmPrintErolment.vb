﻿Public Class frmPrintErolment
    Private Sub frmPrintErolment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class