﻿Public Class frmReceipt

End Class